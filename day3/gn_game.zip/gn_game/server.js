// require express
var express = require("express");
// path module -- try to figure out where and why we use this
var path = require("path");
// create the express app
var session = require('express-session');
var app = express();
var bodyParser = require('body-parser');
var random_number;
var result;
// use it!
app.use(bodyParser.urlencoded({ extended: true }));
// static content
app.use(express.static(path.join(__dirname, "./static")));
// setting up ejs and our views folder
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');
app.use(session({secret: 'codingdojorocks'}));
app.get('/', function(req, res) {
 var result;
 res.render("index",{result:result});
})

app.post('/process', function(req, res) {
  random_number=Math.floor((Math.random()*100)+1)

  // console.log(random_number)
  req.session.result=random_number
  var number=req.body.number
  // console.log("testing,testimng")
  // console.log(req.body)
  console.log(req.body)
  console.log(number)
  console.log(random_number)
  if (number<random_number){
    result="Too low"
  }
  else if (number>random_number){
    result="Too high"
  }
  else if (number==random_number){
    result="You won!"
  }
 res.render("index",{result: result, number: random_number})
})
app.get('/reset', function(req, res) {
  result=''
 res.redirect('/');
})

app.listen(8000, function() {
 console.log("listening on port 8000");
});
