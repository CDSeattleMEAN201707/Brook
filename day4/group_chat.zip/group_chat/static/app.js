$(document). ready(function (){
  var socket  = io. connect();
  var message;
  var user=prompt("Your name:");
  socket.emit("new_user",user)
  socket.on('posts', function(posts){
    console.log(posts)
    $('.messages').empty()
    for (let user in posts){
      $('.messages').append("<p>"+user+": "+posts[user]+" </p>")
    }
  })
  $(document).on('click','button',function(){
    message=$('input').val()
    socket.emit("new_message",{user: user, message: message})
  })


  })
