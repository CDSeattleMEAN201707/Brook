// Require the Express Module
var express = require('express');
// Create an Express App
var app = express();
// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
var mongoose = require('mongoose');
var custom_id=0;
app.use(bodyParser.urlencoded({ extended: true }));
mongoose.connect('mongodb://localhost/message_board');
mongoose.Promise = global.Promise;
var Schema = mongoose.Schema;
var MessageSchema = new mongoose.Schema({
 name: { type: String, required: true, minlength: 4},
 content: { type: String, required: true },
 comments: [{type: Schema.Types.ObjectId, ref: 'Comment'}]
}, { timestamps: true });

var CommentSchema = new mongoose.Schema({
  c_name: { type: String, required: true, minlength: 4},
 _message: {type: Schema.Types.ObjectId, ref: 'Message'},
 comment: { type: String, required: true },
}, {timestamps: true });


mongoose.model('Message', MessageSchema);
mongoose.model('Comment', CommentSchema);

var Message = mongoose.model('Message')
var Comment = mongoose.model('Comment')
// Require path
var path = require('path');
// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
  Message.find({}).populate('comments').exec(function(err,messages){
    // console.log(messages[0].comments[0].content)
    res.render('index',{messages: messages})
  })

})
app.post('/messages/new', function(req,res){
  var message= new Message({name: req.body.name, content: req.body.message})
  message.save(function(err){
        if(err){
            res.render('index', {title: 'you have errors!', errors: message.errors})
        }
        else {
            res.redirect('/');
        }
    });
});

app.post('/messages/:id/comments/new', function(req,res){
  console.log(req.params.id)
  Message.findOne({_id: req.params.id}, function(err, message){
    var comment = new Comment({c_name: req.body.name, comment: req.body.comment});
         comment._message = message._id;
         message.comments.push(comment);
         comment.save(function(err){
                 message.save(function(err){
                       if(err) { console.log('Error'); }
                       else { res.redirect('/'); }
                 });
         });
   });
});








// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
})
