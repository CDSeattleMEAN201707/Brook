// Require the Express Module
var express = require('express');
// Create an Express App
var app = express();
// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
var mongoose = require('mongoose');

app.use(bodyParser.urlencoded({ extended: true }));
mongoose.connect('mongodb://localhost/quoting_dojo');
mongoose.Promise = global.Promise;
var UserSchema = new mongoose.Schema({
 name: String,
 quote: String,
 created_at: { type: Date, default: Date.now },
})
mongoose.model('User', UserSchema);

var User = mongoose.model('User')
// Require path
var path = require('path');
// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
    res.render('index');
})
app.post('/create', function(req, res){
  // User.remove({}, function(err){
  // })
  var user = new User({name: req.body.name, quote: req.body.quote});
  user.save(function(err) {
     if(err){
       console.log('something went wrong');
     }else {
       console.log('successfully added a user!');
      res.redirect('/show');
    }
  })
})
app.get('/show', function(req, res) {
  User.find({}).sort({created_at:-1}).exec(function(err,users){
    res.render('quotes',{users:users});
  })
})
// Add User Request
// app.post('/users', function(req, res) {
//     console.log("POST DATA", req.body);
//     // This is where we would add the user from req.body to the database.
//     res.redirect('/');
// })
// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
    console.log("listening on port 8000");
})
