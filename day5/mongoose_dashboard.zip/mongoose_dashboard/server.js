// Require the Express Module
var express = require('express');
// Create an Express App
var app = express();
// Require body-parser (to receive post data from clients)
var bodyParser = require('body-parser');
// Integrate body-parser with our App
var mongoose = require('mongoose');
var custom_id=0;
app.use(bodyParser.urlencoded({ extended: true }));
mongoose.connect('mongodb://localhost/mongoose_dashboard');
mongoose.Promise = global.Promise;
var AnimalSchema = new mongoose.Schema({
 custom_id: Number,
 name: String,
 animal_class: String,
 created_at: { type: Date, default: Date.now },
})
mongoose.model('Animal', AnimalSchema);

var Animal = mongoose.model('Animal')
// Require path
var path = require('path');
// Setting our Static Folder Directory
app.use(express.static(path.join(__dirname, './static')));
// Setting our Views Folder Directory
app.set('views', path.join(__dirname, './views'));
// Setting our View Engine set to EJS
app.set('view engine', 'ejs');
// Routes
// Root Request
app.get('/', function(req, res) {
  Animal.find({},function(err,animals){
    res.render('index',{animals:animals});
  })
})
app.get('/mongooses/new',function(req,res){
  res.render('new');
})


app.post('/mongooses', function(req, res){
  custom_id=custom_id+1
  var animal = new Animal({custom_id: custom_id,name: req.body.name, animal_class: req.body.animal_class});
  animal.save(function(err) {
     if(err){
       console.log('something went wrong');
     }else {
      //  console.log('successfully added a animal!');
      res.redirect('/');
    }
  })
})

app.get('/mongooses/:id', function(req,res){
  let i=Number(req.params.id)
  var destroy_path="/mongooses/destroy/"+i
  Animal.find({custom_id: i},function(err,animal){
    res.render('mongoose',{animal:animal, destroy_path: destroy_path})
  })

})

app.get('/mongooses/edit/:id',function(req,res){
  let i=Number(req.params.id)
  // console.log("id",i)
  Animal.find({custom_id: i},function(err,animal){
    var edit_path="/mongooses/"+i
    res.render('edit',{animal:animal,edit_path:edit_path})
  })
})

app.post('/mongooses/:id',function(req,res){
  let i=Number(req.params.id)
  console.log("in",i)
  Animal.findOne({ custom_id: i }, function (err, doc){
  console.log("DocDOCDOC",doc)
  doc.name = req.body.name;
  doc.animal_class = req.body.animal_class;
  doc.save();
  res.redirect('/')
  });

})

app.get('/mongooses/destroy/:id', function(req,res){
  let i=Number(req.params.id)
  Animal.remove({custom_id: i}, function(err){
    console.log(err)
    res.redirect('/')
  })

});



// Setting our Server to Listen on Port: 8000
app.listen(8000, function() {
})
