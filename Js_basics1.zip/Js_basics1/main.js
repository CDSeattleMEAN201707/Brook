//basic 1
var x=[];
console.log(x);
x.push("coding","dojo","rocks")
x.pop()
console.log(x);
//basic 2
const y=[];
console.log(y);
y.push(88)
//basic 3
var z=[9,10,6,5,-1,20,13,2];
for (let i=0;i<z.length;i++){console.log(z[i]);}
for (let i=0;i<z.length-1;i++){console.log(z[i]);}
//basic 4
var names=['Kadie', 'Joe', 'Fritz', 'Pierre', 'Alphonso'];
for (let i=0;i<names.length;i++){console.log(names[i].length);}
for (let i=0;i<names.length;i++){
  if (names[i].length===5){
    console.log(names[i]);
  }
}
//basic 5
function yell(string){
  return string.toUpperCase();
}
