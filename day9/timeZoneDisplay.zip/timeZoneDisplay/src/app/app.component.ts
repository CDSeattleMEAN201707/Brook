import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  show: boolean=true
  isclicked= false 
  zones={
    pst: false,
    mst: false,
    cst: false,
    est: false,
  }

  button_click(zone){
    for (let z in this.zones){
      this.zones[z]=false;
    }
    this.zones[zone]=true;
  }
  clear(): void{
    this.zones={
    pst: false,
    mst: false,
    cst: false,
    est: false,
  }
    this.show=false
  }
  today: any;
  offer(offset):void{
    this.show=true
    this.today=Date.now()-(1000*60*60*offset)
  }
  

  
}
