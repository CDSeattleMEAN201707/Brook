import { RanksortPipe } from './ranksort.pipe';

describe('RanksortPipe', () => {
  it('create an instance', () => {
    const pipe = new RanksortPipe();
    expect(pipe).toBeTruthy();
  });
});
