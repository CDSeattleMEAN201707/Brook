import { Component, ChangeDetectionStrategy } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,

})
export class AppComponent {
  quotes=[]

  push_quotes(quote){
    this.quotes.push(quote)
    // console.log( "quote created",this.quotes)
  }
  dispatch(event){
    var idx: number;
    for (let i in this.quotes){
      
      if (this.quotes[i].id===event.id){
        idx=Number(i)
      }

    }
    if (event.message==="voteUp"){
      this.quotes[idx].rank++
    }
    else if(event.message==="voteDown"){
      this.quotes[idx].rank--
    }
    else if(event.message==="delete"){
      this.quotes.splice(idx,1)
    }
    

  }
}
