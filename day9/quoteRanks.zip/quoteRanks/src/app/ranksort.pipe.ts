import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ranksort',
  pure: false,
})
export class RanksortPipe implements PipeTransform {

  transform(quotes: any, args?: any): any {
    if (quotes.length==0){
      console.log('empty')
      return quotes
    }
    console.log("Try me")
    return quotes.sort(function(a,b){
      console.log(a.rank)
      return b.rank-a.rank
    })
    
  }

}
