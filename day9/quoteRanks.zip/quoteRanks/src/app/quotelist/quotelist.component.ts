import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-quotelist',
  templateUrl: './quotelist.component.html',
  styleUrls: ['./quotelist.component.css'],

})
export class QuotelistComponent implements OnInit {
  @Input() listquotes;
  @Output() updateQuotes= new EventEmitter;
  constructor() { }

  ngOnInit() {
  }
  voteUp(id){
    this.updateQuotes.emit({message:'voteUp',id: id})
  }
  voteDown(id){
    this.updateQuotes.emit({message:'voteDown',id: id})
  }
  delete(id){
    this.updateQuotes.emit({message:'delete',id: id})
  }


}
