import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-quotenew',
  templateUrl: './quotenew.component.html',
  styleUrls: ['./quotenew.component.css']
})
export class QuotenewComponent implements OnInit {
  @Output() callParent=new EventEmitter();
  id: number=0;
  quote: object={
    id:"",
    content:"",
    author:"",
    rank: 0,
  }
  constructor() { 
  }

  ngOnInit() {
    
  }
  onSubmit():void{
    console.log(this.quote)
    this.id++
    this.quote["id"]=this.id
    this.callParent.emit(this.quote)
    this.quote={
    id:this.id,
    content:"",
    author:"",
    rank: 0,
  }
  }

}
