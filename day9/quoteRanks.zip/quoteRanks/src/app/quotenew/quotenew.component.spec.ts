import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotenewComponent } from './quotenew.component';

describe('QuotenewComponent', () => {
  let component: QuotenewComponent;
  let fixture: ComponentFixture<QuotenewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuotenewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotenewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
