import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  status=false;
  for_luck;
  users=[]
  password_confirm: string;
  user={
    first_name: "",
    last_name: "",
    email: "",
    password: "",
    street: "",
    unit: "",
    city: "",
    state: "",
    luck: "",
  }
  match_password(){
    return this.user.password!=this.password_confirm
    }
  onSubmit():void{
    this.status=true;
    console.log("user_submitted")
  }
  onClick(){
    this.for_luck=true
    console.log("clicked")
  }
  
}
