import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-supersaiyan3',
  templateUrl: './supersaiyan3.component.html',
  styleUrls: ['./supersaiyan3.component.css']
})
export class Supersaiyan3Component implements OnInit {
  @Input() ss3_power;
  message: any=false;
  custom_power: number;
  constructor() { }

  ngOnInit() {
    
  }
  
  power_message(){
    this.custom_power=this.ss3_power*250
    if (this.custom_power===50000){
       this.message="The One"
    }
    else if (this.custom_power>20000){
      this.message="SuperLative!"
    }
    else if (this.custom_power>9000){
      this.message="Over 9000"
    }
    return this.message
    
  }


}
