import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  input_power: number;
  power: number=100;
  onClick():void{
    if (this.input_power<=100){
       this.power=this.input_power
    }
  }
}
