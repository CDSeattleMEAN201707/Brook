import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-supersaiyan2',
  templateUrl: './supersaiyan2.component.html',
  styleUrls: ['./supersaiyan2.component.css']
})
export class Supersaiyan2Component implements OnInit {
  @Input() ss2_power;
  message: any=false;
  custom_power: number;
  constructor() { }

  ngOnInit() {
    
  }
  
  power_message(){
    this.custom_power=this.ss2_power*150
    if (this.custom_power===50000){
       this.message="The One"
    }
    else if (this.custom_power>20000){
      this.message="SuperLative!"
    }
    else if (this.custom_power>9000){
      this.message="Over 9000"
    }
    return this.message
    
  }

  

}
