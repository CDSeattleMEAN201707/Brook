import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-supersaiyan',
  templateUrl: './supersaiyan.component.html',
  styleUrls: ['./supersaiyan.component.css']
})
export class SupersaiyanComponent implements OnInit {
  @Input() ss_power;
  message: any=false;
  custom_power: number;
  constructor() { }

  ngOnInit() {
    
  }
  
  power_message(){
    this.custom_power=this.ss_power*90
    if (this.custom_power===50000){
       this.message="The One"
    }
    else if (this.custom_power>20000){
      this.message="SuperLative!"
    }
    else if (this.custom_power>9000){
      this.message="Over 9000"
    }
    return this.message
    
  }


}
