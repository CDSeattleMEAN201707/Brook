import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-saiyan',
  templateUrl: './saiyan.component.html',
  styleUrls: ['./saiyan.component.css']
})
export class SaiyanComponent implements OnInit {
   @Input() saiyan_power;
  message: any=false;
  custom_power: number;
  
  constructor() { }

  ngOnInit() {
  }
  
  power_message(){
    this.custom_power=this.saiyan_power*10
    if (this.custom_power===50000){
       this.message="The One"
    }
    else if (this.custom_power>20000){
      this.message="SuperLative!"
    }
    else if (this.custom_power>9000){
      this.message="Over 9000"
    }
    return this.message
    
  }



}
