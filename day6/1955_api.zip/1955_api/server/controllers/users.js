var mongoose = require('mongoose');
var User = mongoose.model('User');

module.exports ={
  index: function(req,res){
     User.find({},function(err,users){
      res.json(users)

    })
  },
  add_user: function(req,res){
    let user= new User({name: req.params.name})
    user.save()
    res.redirect('/')
  },
  remove_user: function(req,res){
    console.log(req.params.name.constructor)
    User.remove({name: req.params.name}, function(err){
      console.log(err)
    })
    res.redirect('/')
  },
  get_user: function(req,res){
    User.findOne({name:req.params.name}, function(err,user){
      res.json(user)
    })
  }
}
