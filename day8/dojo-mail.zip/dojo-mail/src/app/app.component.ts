import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  users=[{
    email: "Billgates@gmail.com",
    importance: true,
    subject: "New Windows",
    content: "Some night today",
  },
  {
    email: "Bobgates@gmail.com",
    importance: false,
    subject: "New times",
    content: "Some day ",
  },
  {
    email: "Suegates@gmail.com",
    importance: true,
    subject: "New cat",
    content: "Some day today",
  },
  {
    email: "Billgates@gmail.com",
    importance: false,
    subject: "New car",
    content: "Some day again",
  }]
}
