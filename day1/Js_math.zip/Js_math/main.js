function zero_negativity(arr){
  for(let i=0;i<arr.length;i++){
    if (arr[i]<1){
      return false;
    }
  }
  return true
}


function is_even(num){
  if (num%2==0){
    return true
  }
  return false
}


function how_many_even(arr){
  var count_even=0
  for(let i=0;i<arr.length;i++){
    if (arr[i]%2==0){
      count_even++;
    }
  }
  return count_even;
}

function create_dummy_array(n){
  var res=[]
  for(let i=0; i<n; i++){
    res.push(Math.floor(Math.random()*10))
  }
  return res
}

function random_choice(arr){
    var idx=Math.floor(Math.random()*arr.length)
    return arr[idx]
}
