function magic_multiply(x, y){
    var product="";
    if (y.constructor==String) {
      return "Error: Can not multiply by string"
    }
    else if(x.constructor==Array){
      for (let i=0;i<x.length;i++){
        x[i]=x[i]*y
      }
      return x
    }
    else if(x.constructor==String){
      for (let i=0;i<y;i++){
        console.log(x)
      }
    }
    else{
      return x*y;
    }
}
